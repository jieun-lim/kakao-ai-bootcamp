import scrapy


class MusinsaItem(scrapy.Item):
    product_name = scrapy.Field() # 제품명
    brand = scrapy.Field() # 브랜드
    product_id = scrapy.Field() # 품번
    season = scrapy.Field() # 시즌
    sex = scrapy.Field() # 성별
    like = scrapy.Field() # 좋아요
    release_info = scrapy.Field() # 출고 정보
    shipping_info = scrapy.Field() # 배송정보
    price = scrapy.Field() # 무신사 판매가
    member_price = scrapy.Field() # 무신사 회원가
    point = scrapy.Field() # 무신사 적립금
    product_img = scrapy.Field() # 제품 이미지
    product_info = scrapy.Field() # 제품 설명